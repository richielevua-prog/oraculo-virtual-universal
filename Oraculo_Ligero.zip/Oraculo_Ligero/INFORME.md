# Entrega verificada — Oráculo Matemático Universal

## Resultado real

- Entradas únicas (grafía NFC, idioma): **2,047,769**.
- Grafías distintas: **1,836,771**.
- Códigos de idioma/variedad: **887**, con cobertura muy desigual.
- Entradas elegibles por defecto: **1,818,624**.
- Español: 861,868; inglés: 60,196;
  japonés: 93,095; latín: 5,836;
  griego antiguo: 271; náhuatl clásico: 2,795.
- Base SQLite: 581,722,112 bytes, integridad **ok**.
- 15 pruebas funcionales aprobadas; 7 comprobaciones del prototipo aprobadas.
- 10.000 extracciones sin repetir grafías, sin fallos.

## Rendimiento medido

Tabla temporal inicial: 7.07 segundos.
Latencia de 1.000 generaciones por modo, sin impresión en terminal:

| Modo | Mediana ms | Percentil 95 ms |
|---|---:|---:|
| A | 0.894 | 1.995 |
| B | 0.781 | 1.408 |
| C | 0.871 | 1.467 |

La prueba de 10.000 extracciones sin repetición, incluida preparación del pool,
tardó 17.07 segundos.
Diagnóstico de frecuencias: 100.000 muestras, 10 casillas, chi cuadrado
7.2188 con 9 grados de libertad. No demuestra seguridad
criptográfica ni capacidad de predicción.

Se verificó en Linux-6.18.44-x86_64-with-glibc2.39, Python 3.12.14. No se ejecutó en Windows ni se
entrega un EXE probado. Los lanzadores BAT y el código Python están preparados
para instalación en Windows; sigue LEEME.md.

## Transparencia

No es un diccionario completo de la humanidad. No garantiza exhaustividad de
ninguna disciplina, idioma o familia de nombres propios. No es una carta natal
completa. No se verificó el Reel ni una supuesta predicción de Terry Davis.
La aplicación incluye simbolismo configurable, no poderes sobrenaturales.

Fuentes, licencias, auditoría y procedimientos: FUENTES_Y_LICENCIAS.md,
AUDITORIA.md y LEEME.md. Detalle de todos los códigos: cobertura.csv.

SHA256 de la base: `d80e518b98f521ef0c70d5fc5c4e3bcf18c6677f8143120dafdd01a9ea54cc9e`.
