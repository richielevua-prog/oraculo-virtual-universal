"""Pruebas y mediciones reales; no altera los datos léxicos."""
import sys,json,time,sqlite3,statistics,hashlib,platform,collections
from pathlib import Path
from motor import connect,Pool,Deterministic,profile
BASE=Path(__file__).resolve().parent

def run():
 path=BASE/'data/lexico.sqlite';c=connect(path)
 integrity=c.execute('PRAGMA integrity_check').fetchall()
 if integrity!=[('ok',)]:raise RuntimeError('Integridad fallida: '+str(integrity[:3]))
 langs=c.execute('SELECT lang,count(*) FROM entries GROUP BY lang ORDER BY lang').fetchall()
 t=time.perf_counter();p=Pool(c);build=time.perf_counter()-t
 prof=profile('Persona de prueba','2000-03-20');times=[]
 for mode in ['A','B','C']:
  rng=Deterministic('benchmark');measure=[]
  for i in range(1000):
   t=time.perf_counter();p.draw(mode,prof,rng);measure.append((time.perf_counter()-t)*1000)
  times.append({'mode':mode,'draws':1000,'median_ms':statistics.median(measure),'p95_ms':sorted(measure)[949]})
 t=time.perf_counter();p=Pool(c);rng=Deterministic('norepeat');seen=set()
 for i in range(10000):
  w=p.draw('C',prof,rng,True)['word'];assert w not in seen;seen.add(w)
 no_repeat_seconds=time.perf_counter()-t
 # Seeded distribution check on uniform integer source; diagnostic, not CSPRNG certification.
 r=Deterministic('chi-square-v1');bins=collections.Counter(r.randbelow(10) for _ in range(100000));chi=sum((bins[i]-10000)**2/10000 for i in range(10))
 report={'platform':platform.platform(),'python':sys.version,'database_bytes':path.stat().st_size,'database_sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'integrity':integrity,'entries_word_language':sum(n for l,n in langs),'distinct_spellings':c.execute('SELECT count(DISTINCT word) FROM entries').fetchone()[0],'language_codes':len(langs),'languages':dict(langs),'eligible_without_spaces_underscores':sum(Pool(c).counts.values()),'pool_build_seconds':build,'latency':times,'no_repeat_10000_including_pool_seconds':no_repeat_seconds,'uniform_rng_100000_bins':dict(bins),'chi_square_df9':chi,'chi_note':'diagnostic, no proof of cryptographic security'}
 (BASE/'informe_verificacion.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf8')
 sources=dict(c.execute('SELECT id,metadata FROM sources'));(BASE/'fuentes.json').write_text(json.dumps({k:json.loads(v) for k,v in sources.items()},indent=2,ensure_ascii=False),encoding='utf8')
 print(json.dumps(report,ensure_ascii=False,indent=2));c.close()
if __name__=='__main__':run()
