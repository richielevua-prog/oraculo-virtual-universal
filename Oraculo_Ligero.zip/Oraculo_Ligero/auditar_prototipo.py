import json
from datetime import date
import prototipo_original as p
bags=p.preparar_bolsas();flat=[x for b in bags.values() for x in b]
assert len(flat)==len(set(flat))==159
assert p.numero_reducido(999)==9
assert p.numerologia_nacimiento(date(2000,3,20))==7
assert p.numerologia_nombre('ÁBC')==6
assert p.signo_aproximado(date(2000,3,20))[0]=='Piscis'
weights=p.pesos_personales('Persona Prueba',date(2000,3,20),'agua',7,6,0)
for i in range(159):
 cat=p.elegir_categoria(weights,bags);bags[cat].pop()
assert not any(bags.values())
print(json.dumps({'unique_words':len(flat),'categories':len(bags),'checks_passed':7,'solar_sign_test':'fixed-calendar approximation, not astronomical verification'}))
