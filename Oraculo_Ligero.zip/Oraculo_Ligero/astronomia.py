from datetime import datetime, timezone
from pathlib import Path
from skyfield.api import Loader, load_file
from skyfield.framelib import ecliptic_frame
from skyfield import almanac
from skyfield_data import get_skyfield_data_path

def calculate(iso):
    dt=datetime.fromisoformat(iso)
    if dt.tzinfo is None:raise ValueError('La hora astronómica requiere offset UTC, ejemplo -06:00')
    folder=Path(get_skyfield_data_path())
    load=Loader(str(folder));ts=load.timescale(builtin=True)
    eph=load_file(str(folder/'de421.bsp'))
    try:
        t=ts.from_datetime(dt);earth=eph['earth'];values={}
        for body in ['sun','moon','mercury','venus','mars','jupiter barycenter','saturn barycenter','uranus barycenter','neptune barycenter']:
            lat,lon,distance=earth.at(t).observe(eph[body]).apparent().frame_latlon(ecliptic_frame)
            values[body]={'longitude_deg':round(lon.degrees,8),'latitude_deg':round(lat.degrees,8),'distance_au':round(distance.au,10)}
        return {'utc':dt.astimezone(timezone.utc).isoformat(),'ephemeris':'JPL DE421','frame':'geocentric apparent true ecliptic of date',
                'positions':values,'moon_phase_deg':round(almanac.moon_phase(eph,t).degrees,8),
                'moon_illuminated_fraction':round(almanac.fraction_illuminated(eph,'moon',t),8),
                'symbolic_tropical_sign_index':int(values['sun']['longitude_deg']//30)}
    finally:eph.close()
