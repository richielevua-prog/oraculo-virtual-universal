import unittest,tempfile,zipfile,json,io,sys
from pathlib import Path
from unittest.mock import patch
from contextlib import redirect_stdout
import oraculo
from motor import connect,add
from importar import omw,kaikki
class Integracion(unittest.TestCase):
 def test_import_omw_two_tag_formats(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);z=d/'test.zip'
   with zipfile.ZipFile(z,'w') as f:f.writestr('omw-1.4/es/wn-data-spa.tab','# Test\tspa\thttps://example.org\tMIT\n00000001-n\tlemma\tcafé\n00000002-n\tspa:lemma\tcafe\u0301\n')
   with redirect_stdout(io.StringIO()):omw(d/'db',z,d/'licenses')
   c=connect(d/'db');self.assertEqual(c.execute('select count(*) from entries').fetchone()[0],1);self.assertEqual(c.execute('select count(*) from provenance').fetchone()[0],2);c.close()
 def test_kaikki_iso_and_idempotency(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);f=d/'test.jsonl';f.write_text(json.dumps({'word':'café','lang_code':'es','pos':'noun'})+'\n',encoding='utf8')
   for _ in range(2):kaikki(d/'db',f,'https://example.org','MIT')
   c=connect(d/'db');self.assertEqual(c.execute('select word,lang,pos from entries').fetchall(),[('café','spa','n')]);c.close()
 def test_console_history_exports(self):
  with tempfile.TemporaryDirectory() as d:
   d=Path(d);c=connect(d/'db');add(c,'café','spa','n','test');add(c,'árbol','spa','n','test');c.commit();c.close()
   # Initial prompts then commands; fixed instant, seed, no-repeat, opt-in history.
   answers=iter(['Persona Prueba','2000-03-20','','','2000-03-20T12:00:00+00:00','C','test','s','s','','','/ultimo','/info','/historial','/exportar csv','/exportar json','/salir'])
   output=io.StringIO()
   with patch.object(oraculo,'BASE',d),patch.object(sys,'argv',['oraculo.py','--db',str(d/'db')]),patch('builtins.input',side_effect=lambda *a:next(answers)),redirect_stdout(output):oraculo.main()
   exported=list((d/'historial').glob('*.json'));self.assertEqual(len(exported),1)
   data=json.loads(exported[0].read_text());self.assertEqual(len(data),2);self.assertEqual(len({r['word'] for r in data}),2)
   self.assertEqual(len(list((d/'historial').glob('*.csv'))),1)
if __name__=='__main__':unittest.main(verbosity=2)
