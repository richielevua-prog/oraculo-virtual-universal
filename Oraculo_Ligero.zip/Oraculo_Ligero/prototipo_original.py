#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Oráculo simbólico personalizado. Python 3.9+, sin paquetes externos.

No predice el futuro. Usa astronomía lunar aproximada, numerología y
aleatoriedad criptográfica para explorar asociaciones de palabras.
"""

from __future__ import annotations

import hashlib
import secrets
import unicodedata
from datetime import date, datetime, timezone

# Añade o quita palabras aquí. Cada palabra aparecerá, como máximo, una vez
# por vuelta completa del vocabulario, incluso si pertenece a varios grupos.
PALABRAS = {
    "cosmos": [
        "estrella", "órbita", "eclipse", "cometa", "constelación", "vacío",
        "galaxia", "nebulosa", "infinito", "luz", "gravedad", "satélite",
        "aurora", "horizonte", "meteorito", "universo", "planeta", "sol",
        "luna", "espacio",
    ],
    "naturaleza": [
        "bosque", "océano", "tormenta", "semilla", "raíz", "flor",
        "viento", "desierto", "montaña", "río", "lluvia", "ceniza",
        "fuego", "niebla", "roca", "árbol", "marea", "trueno",
        "nieve", "tierra",
    ],
    "cambio": [
        "renacer", "ruptura", "comienzo", "viaje", "umbral", "decisión",
        "giro", "oportunidad", "equilibrio", "avance", "retorno", "crisis",
        "crecimiento", "transición", "revelación", "camino", "riesgo",
        "transformación", "elección", "libertad",
    ],
    "sociedad": [
        "ciudad", "alianza", "multitud", "frontera", "comunidad", "acuerdo",
        "poder", "justicia", "gobierno", "historia", "mercado", "cultura",
        "mensaje", "protesta", "voto", "nación", "política", "sistema",
        "dinero", "conexión",
    ],
    "interior": [
        "memoria", "sueño", "deseo", "confianza", "miedo", "valentía",
        "silencio", "recuerdo", "intuición", "amor", "duda", "calma",
        "presencia", "identidad", "conciencia", "anhelo", "espejo",
        "voluntad", "sentido", "esperanza",
    ],
    "tiempo": [
        "ayer", "mañana", "instante", "ciclo", "etapa", "destino",
        "origen", "futuro", "pasado", "ritmo", "momento", "espera",
        "reloj", "estación", "secuencia", "sincronía", "era", "fecha",
        "pausa", "continuidad",
    ],
    "ciencia": [
        "código", "algoritmo", "número", "energía", "señal", "máquina",
        "virus", "célula", "átomo", "red", "dato", "circuito", "teoría",
        "patrón", "probabilidad", "materia", "experimento", "modelo",
        "electricidad", "inteligencia",
    ],
    "misterio": [
        "símbolo", "puerta", "clave", "secreto", "pregunta", "eco",
        "presagio", "enigma", "coincidencia", "azar", "paradoja",
        "señal", "máscara", "destello", "azaroso", "sombra", "portal",
        "laberinto", "visión", "interpretación",
    ],
}

SIGNOS = [
    ((1, 20), "Acuario", "aire"), ((2, 19), "Piscis", "agua"),
    ((3, 21), "Aries", "fuego"), ((4, 20), "Tauro", "tierra"),
    ((5, 21), "Géminis", "aire"), ((6, 21), "Cáncer", "agua"),
    ((7, 23), "Leo", "fuego"), ((8, 23), "Virgo", "tierra"),
    ((9, 23), "Libra", "aire"), ((10, 23), "Escorpio", "agua"),
    ((11, 22), "Sagitario", "fuego"), ((12, 22), "Capricornio", "tierra"),
]

REF_LUNA_NUEVA = datetime(2000, 1, 6, 18, 14, tzinfo=timezone.utc)
MES_SINODICO = 29.530588853  # días, promedio; no es una efeméride precisa
FASES = [
    "luna nueva", "creciente inicial", "cuarto creciente", "gibosa creciente",
    "luna llena", "gibosa menguante", "cuarto menguante", "menguante final",
]


def numero_reducido(n: int) -> int:
    while n > 9:
        n = sum(int(c) for c in str(n))
    return n


def numerologia_nombre(nombre: str) -> int:
    letras = unicodedata.normalize("NFKD", nombre.upper())
    letras = "".join(c for c in letras if "A" <= c <= "Z")
    if not letras:
        raise ValueError("Escribe un nombre que contenga letras A-Z.")
    # Sistema numerológico pitagórico: A=1,...I=9,J=1,...
    return numero_reducido(sum(((ord(c) - ord("A")) % 9) + 1 for c in letras))


def numerologia_nacimiento(nacimiento: date) -> int:
    return numero_reducido(sum(int(x) for x in nacimiento.strftime("%Y%m%d")))


def signo_aproximado(nacimiento: date) -> tuple[str, str]:
    signo, elemento = "Capricornio", "tierra"
    for inicio, nombre, elem in SIGNOS:
        if (nacimiento.month, nacimiento.day) >= inicio:
            signo, elemento = nombre, elem
    return signo, elemento


def fase_lunar_estimada() -> tuple[int, str, float]:
    dias = (datetime.now(timezone.utc) - REF_LUNA_NUEVA).total_seconds() / 86400
    edad_lunar = dias % MES_SINODICO
    indice = int(8 * edad_lunar / MES_SINODICO + 0.5) % 8
    return indice, FASES[indice], edad_lunar


def pesos_personales(nombre: str, nacimiento: date, elemento: str,
                     n_vida: int, n_nombre: int, indice_luna: int) -> dict[str, int]:
    claves = list(PALABRAS)
    pesos = {cat: 6 for cat in claves}
    pareja_elemental = {
        "fuego": ("cambio", "naturaleza"),
        "tierra": ("naturaleza", "tiempo"),
        "aire": ("sociedad", "ciencia"),
        "agua": ("interior", "misterio"),
    }
    for categoria in pareja_elemental[elemento]:
        pesos[categoria] += 4

    pesos[claves[(n_vida - 1) % len(claves)]] += 5
    pesos[claves[(n_nombre - 1) % len(claves)]] += 3
    pesos[claves[indice_luna]] += 4

    # La huella del nombre y fecha cambia el reparto, NO predice eventos.
    datos = (nombre.strip().casefold() + "|" + nacimiento.isoformat()).encode("utf-8")
    huella = hashlib.sha256(datos).digest()
    for i, categoria in enumerate(claves):
        pesos[categoria] += huella[i] % 4
    return pesos


def elegir_categoria(pesos: dict[str, int], opciones: dict[str, list[str]]) -> str:
    candidatas = [(cat, peso) for cat, peso in pesos.items() if opciones[cat]]
    total = sum(peso for _, peso in candidatas)
    boleto = secrets.randbelow(total)  # selección uniforme de un entero [0,total)
    acumulado = 0
    for categoria, peso in candidatas:
        acumulado += peso
        if boleto < acumulado:
            return categoria
    raise RuntimeError("Error interno al elegir categoría")


def preparar_bolsas() -> dict[str, list[str]]:
    # Un vocabulario exclusivo por categoría (sin duplicados en toda la sesión).
    vistos: set[str] = set()
    bolsas = {}
    for categoria, palabras in PALABRAS.items():
        exclusivas = []
        for palabra in palabras:
            if palabra not in vistos:
                vistos.add(palabra)
                exclusivas.append(palabra)
        bolsas[categoria] = exclusivas
    return bolsas


def obtener_fecha() -> date:
    while True:
        entrada = input("Fecha de nacimiento (DD/MM/AAAA): ").strip()
        try:
            return datetime.strptime(entrada, "%d/%m/%Y").date()
        except ValueError:
            print("Fecha no válida. Ejemplo: 20/03/2000\n")


def main() -> None:
    print("=" * 55)
    print(" ORÁCULO PERSONAL | AZAR + NÚMEROS + SIMBOLISMO ")
    print("=" * 55)
    print("Experimento simbólico: NO hace predicciones reales.\n")

    while True:
        nombre = input("Tu nombre: ").strip()
        try:
            n_nombre = numerologia_nombre(nombre)
            break
        except ValueError as exc:
            print(exc)

    nacimiento = obtener_fecha()
    n_vida = numerologia_nacimiento(nacimiento)
    signo, elemento = signo_aproximado(nacimiento)
    indice, fase, edad_luna = fase_lunar_estimada()
    pesos = pesos_personales(nombre, nacimiento, elemento, n_vida, n_nombre, indice)
    disponibles = preparar_bolsas()
    total_palabras = sum(map(len, disponibles.values()))

    print("\n--- PERFIL SIMBÓLICO ---")
    print(f"Nombre: {nombre} | nacimiento: {nacimiento.strftime('%d/%m/%Y')}")
    print(f"Signo solar orientativo: {signo} ({elemento})")
    print(f"Número de nacimiento: {n_vida} | número de nombre: {n_nombre}")
    print(f"Fase lunar estimada HOY: {fase} (edad lunar ≈ {edad_luna:.1f} días)")
    print("AVISO: el signo por fecha es orientativo, especialmente en días de transición.")
    print(f"Vocabulario: {total_palabras} palabras sin repetir por ciclo.")
    print("\nPresiona ENTER para generar una palabra.")
    print("Escribe 'info' para ver las probabilidades o 'salir' para terminar.\n")

    contador = 0
    try:
        while True:
            orden = input("> ").strip().lower()
            if orden in {"salir", "exit", "q"}:
                print("Fin de la sesión.")
                return
            if orden == "info":
                indice, fase, edad_luna = fase_lunar_estimada()
                pesos = pesos_personales(nombre, nacimiento, elemento, n_vida, n_nombre, indice)
                activos = {cat: peso for cat, peso in pesos.items() if disponibles[cat]}
                total = sum(activos.values())
                print(f"Fase lunar orientativa actual: {fase}")
                for categoria, peso in activos.items():
                    print(f"  {categoria:12} {100 * peso / total:5.1f}%")
                continue
            if orden:
                print("Presiona solo ENTER, escribe 'info' o escribe 'salir'.")
                continue
            if not any(disponibles.values()):
                disponibles = preparar_bolsas()
                print("[Comienza un nuevo ciclo del vocabulario]")

            indice, _, _ = fase_lunar_estimada()
            pesos = pesos_personales(nombre, nacimiento, elemento, n_vida, n_nombre, indice)
            categoria = elegir_categoria(pesos, disponibles)
            lista = disponibles[categoria]
            palabra = lista.pop(secrets.randbelow(len(lista)))
            contador += 1
            print(f"\n{palabra.upper()}\n")
    except (KeyboardInterrupt, EOFError):
        print("\nFin de la sesión.")


if __name__ == "__main__":
    main()
