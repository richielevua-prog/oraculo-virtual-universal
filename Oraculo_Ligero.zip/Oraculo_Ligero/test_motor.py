import unittest,tempfile,json,collections,math
from pathlib import Path
from motor import *
from oraculo import natal_time
from astronomia import calculate
class TestMotor(unittest.TestCase):
 def db(self):
  c=connect(':memory:')
  for w,l,p in [('a','es','n'),('b','es','n'),('c','en','v'),('a','en','v')]:add(c,w,l,p,'test')
  c.commit();return c
 def test_unicode_dedup(self):
  c=self.db();add(c,'café','es','n','test','1');add(c,'cafe\u0301','es','v','test','2');self.assertEqual(c.execute('select count(*) from entries').fetchone()[0],5)
  self.assertEqual(c.execute('select count(*) from provenance where entry=(select id from entries where word="café")').fetchone()[0],2)
 def test_empty(self):
  with self.assertRaises(LookupError):Pool(self.db(),['absent']).draw('A',{})
 def test_no_repeat_surface(self):
  p=Pool(self.db());out=[p.draw('C',{},Deterministic(str(i)),True)['word'] for i in range(3)];self.assertEqual(len(set(out)),3)
  with self.assertRaises(LookupError):p.draw('A',{})
 def test_reproduce(self):
  p=Pool(self.db());r=Deterministic('x');a=[p.draw('C',{},r)['id'] for _ in range(100)]
  p=Pool(self.db());r=Deterministic('x');b=[p.draw('C',{},r)['id'] for _ in range(100)];self.assertEqual(a,b)
 def test_uniform_probability(self):
  p=Pool(self.db());r=Deterministic('test');counts=collections.Counter()
  for i in range(20000):
   x=p.draw('C',{},r);counts[x['id']]+=1;self.assertEqual(x['probability_numerator']/x['probability_denominator'],.25)
  chi=sum((n-5000)**2/5000 for n in counts.values());self.assertLess(chi,25)
 def test_weight_probability(self):
  p=Pool(self.db());prof={'life':3};weights={g:1+int.from_bytes(hashlib.sha256((canonical(prof)+'|'+g).encode()).digest()[:8],'big')%100 for g in p.counts}
  total=sum(weights[g]*n for g,n in p.counts.items())
  for i in range(100):
   x=p.draw('B',prof);self.assertEqual(x['probability_numerator'],weights[x['group']]);self.assertEqual(x['probability_denominator'],total)
 def test_numerology(self):
  x=profile('Ábc','2000-03-20');self.assertEqual(x['name_number'],6);self.assertEqual(x['life_number'],7)
  self.assertIsNone(profile('王','2000-03-20')['name_number'])
  with self.assertRaises(ValueError):profile('x','2000-02-30')
 def test_dst(self):
  with self.assertRaises(ValueError):natal_time('2024-03-10','02:30','America/New_York',0)
  self.assertNotEqual(natal_time('2024-11-03','01:30','America/New_York',0),natal_time('2024-11-03','01:30','America/New_York',1))
 def test_astronomy(self):
  a=calculate('2000-03-20T12:00:00+00:00');b=calculate('2000-03-20T06:00:00-06:00');self.assertEqual(a,b)
  self.assertLess(a['positions']['sun']['longitude_deg'],1);self.assertTrue(0<=a['moon_illuminated_fraction']<=1)
  with self.assertRaises(ValueError):calculate('2000-03-20T12:00:00')
 def test_filters_and_seen(self):
  p=Pool(self.db(),['es'],seen=['a']);self.assertEqual(sum(p.counts.values()),1);self.assertEqual(p.draw('A',{})['word'],'b')
 def test_symbolic_rule(self):
  p={'astronomy':{'symbolic_tropical_sign_index':0},'symbolic_rules':{'sign_pos_multipliers':{'0':{'n':3}}}}
  self.assertEqual(symbolic_multiplier(p,'spa|n'),3)
  self.assertEqual(symbolic_multiplier(p,'spa|v'),1)
  p['symbolic_rules']['sign_pos_multipliers']['0']['n']=0
  with self.assertRaises(ValueError):symbolic_multiplier(p,'spa|n')
 def test_rng_range(self):
  r=Deterministic('test')
  for n in [1,2,3,256,257,2**300]:self.assertTrue(all(0<=r.randbelow(n)<n for _ in range(50)))
if __name__=='__main__':unittest.main(verbosity=2)
