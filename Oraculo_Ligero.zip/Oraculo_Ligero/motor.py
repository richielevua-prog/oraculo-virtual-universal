"""Motor local v1. Python 3.11+. Sin conexiones de red."""
import sqlite3, hashlib, hmac, secrets, json, unicodedata
from datetime import date, datetime, timezone
from pathlib import Path

def canonical(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def reduce(n):
    while n>9: n=sum(map(int,str(n)))
    return n

def profile(name,birth):
    birth=date.fromisoformat(birth)
    if birth>date.today(): raise ValueError('Nacimiento futuro')
    name=unicodedata.normalize('NFC',name.strip())
    if not name: raise ValueError('Nombre vacío')
    letters=''.join(c for c in unicodedata.normalize('NFKD',name.upper()) if 'A'<=c<='Z')
    total=sum((ord(c)-65)%9+1 for c in letters)
    return {'name_number':reduce(total) if letters else None,'name_sum':total,'latin_letters':letters,
      'life_number':reduce(sum(map(int,birth.strftime('%Y%m%d')))),
      'fingerprint':hashlib.sha256(canonical([name,birth.isoformat()]).encode()).hexdigest()}

class Deterministic:
    """HMAC-SHA256 contador, rechazo exacto; semilla pública => predecible."""
    def __init__(self,seed): self.key=hashlib.sha256(seed.encode()).digest(); self.counter=0
    def randbelow(self,n):
        if n<=0: raise ValueError('n debe ser positivo')
        k=(n.bit_length()+7)//8
        while True:
            b=b''
            while len(b)<k:
                b+=hmac.new(self.key,self.counter.to_bytes(16,'big'),hashlib.sha256).digest(); self.counter+=1
            x=int.from_bytes(b[:k],'big'); limit=256**k-(256**k%n)
            if x<limit:return x%n

SCHEMA='''
CREATE TABLE IF NOT EXISTS entries(id INTEGER PRIMARY KEY, word TEXT NOT NULL,lang TEXT NOT NULL,pos TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'unknown', UNIQUE(word,lang));
CREATE INDEX IF NOT EXISTS entry_filter ON entries(lang,pos,kind);
CREATE INDEX IF NOT EXISTS entry_word ON entries(word);
CREATE TABLE IF NOT EXISTS sources(id TEXT PRIMARY KEY,metadata TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS provenance(entry INTEGER,source TEXT,tag TEXT,PRIMARY KEY(entry,source,tag));
'''
def connect(path):
    c=sqlite3.connect(path);c.executescript(SCHEMA);return c

def add(c,word,lang,pos,source,tag='',kind='unknown'):
    word=unicodedata.normalize('NFC',word.strip())
    if not word or any(unicodedata.category(ch).startswith('C') for ch in word): return
    c.execute('INSERT OR IGNORE INTO entries(word,lang,pos,kind) VALUES(?,?,?,?)',(word,lang,pos,kind))
    eid=c.execute('SELECT id FROM entries WHERE word=? AND lang=?',(word,lang)).fetchone()[0]
    # Primary POS deterministic, independent of import order; all original tags retained.
    c.execute('UPDATE entries SET pos=min(pos,?),kind=CASE WHEN kind="unknown" THEN ? ELSE kind END WHERE id=?',(pos,kind,eid))
    c.execute('INSERT OR IGNORE INTO provenance VALUES(?,?,?)',(eid,source,tag or pos))

def symbolic_multiplier(prof,group):
    sign=prof.get('astronomy',{}).get('symbolic_tropical_sign_index')
    rules=prof.get('symbolic_rules',{}).get('sign_pos_multipliers',{})
    value=rules.get(str(sign),{}).get(group.split('|',1)[1],1)
    if type(value) is not int or not 1<=value<=1000:raise ValueError('Multiplicador simbólico: entero entre 1 y 1000')
    return value

class Pool:
    def __init__(self,c,langs=(),poses=(),kinds=(),phrases=False,seen=()):
        self.c=c;self.weight_cache={}
        c.execute('DROP TABLE IF EXISTS temp.pool')
        c.execute('CREATE TEMP TABLE pool(g TEXT,slot INTEGER,eid INTEGER UNIQUE,PRIMARY KEY(g,slot)) WITHOUT ROWID')
        where=[];args=[]
        for col,vals in [('lang',langs),('pos',poses),('kind',kinds)]:
            if vals: where.append(col+' IN ('+','.join('?'*len(vals))+')');args.extend(vals)
        if not phrases: where.append("instr(word,' ')=0 AND instr(word,'_')=0")
        query='SELECT id,lang,pos,word FROM entries'+(' WHERE '+' AND '.join(where) if where else '')+' ORDER BY lang,pos,id'
        self.counts={}; seen=set(seen)
        for eid,lang,pos,word in c.execute(query,args):
            if word in seen:continue
            g=lang+'|'+pos;n=self.counts.get(g,0)
            c.execute('INSERT INTO pool VALUES(?,?,?)',(g,n,eid));self.counts[g]=n+1
        c.commit()
    def remove_word(self,word):
        rows=self.c.execute('SELECT p.g,p.slot,p.eid FROM pool p JOIN entries e ON e.id=p.eid WHERE e.word=?',(word,)).fetchall()
        # Query fresh slot because prior swaps can move another matching entry.
        for _,_,eid in rows:
            g,slot=self.c.execute('SELECT g,slot FROM pool WHERE eid=?',(eid,)).fetchone()
            n=self.counts[g]
            self.c.execute('DELETE FROM pool WHERE g=? AND slot=?',(g,slot))
            if slot!=n-1:self.c.execute('UPDATE pool SET slot=? WHERE g=? AND slot=?',(slot,g,n-1))
            self.counts[g]-=1
    def draw(self,mode,prof,rng=None,no_repeat=False):
        rnd=rng.randbelow if mode=='C' else secrets.randbelow
        groups=[(g,n) for g,n in sorted(self.counts.items()) if n]
        if not groups:raise LookupError('Vocabulario agotado; usa /reiniciar explícitamente')
        if mode=='B':
            payload=canonical(prof)
            if payload not in self.weight_cache:
                self.weight_cache[payload]={g:(1+int.from_bytes(hashlib.sha256((payload+'|'+g).encode()).digest()[:8],'big')%100)*symbolic_multiplier(prof,g) for g in self.counts}
            weights=self.weight_cache[payload]
        else:weights={g:1 for g,n in groups}
        total=sum(n*weights[g] for g,n in groups);ticket=rnd(total)
        for g,n in groups:
            mass=n*weights[g]
            if ticket<mass:break
            ticket-=mass
        slot=rnd(n)
        eid=self.c.execute('SELECT eid FROM pool WHERE g=? AND slot=?',(g,slot)).fetchone()[0]
        row=self.c.execute('SELECT word,lang,pos,kind FROM entries WHERE id=?',(eid,)).fetchone()
        sources=self.c.execute('SELECT source,tag FROM provenance WHERE entry=? ORDER BY source,tag',(eid,)).fetchall()
        result=dict(zip(['word','lang','pos','kind'],row));result.update(id=eid,sources=sources,mode=mode,probability_numerator=weights[g],probability_denominator=total,group=g)
        if no_repeat:self.remove_word(row[0])
        return result
