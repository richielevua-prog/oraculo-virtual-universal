# Auditoría del prototipo y alcance

Se recuperó el contenido actual de `oraculo_personal.py` (247 líneas) y se
conserva como `prototipo_original.py`. Las pruebas reproducibles están en
`auditar_prototipo.py` y su resultado en `auditoria_prototipo.json`.

Resultados: 160 posiciones declaradas, 159 grafías únicas, ocho categorías.
«señal» pertenece a dos listas y queda asignada a la primera. `secrets.randbelow`
es una elección adecuada. El algoritmo de bolsas evita repetir dentro del ciclo,
pero reinicia automáticamente al agotarse. Las categorías se ponderan antes de
elegir palabra; no equivale a distribución uniforme por entrada y las
probabilidades cambian al vaciarse las bolsas. `info` informa probabilidades de
categorías, no de cada palabra. La fase lunar usa un período medio, no efemérides.
El signo solar usa límites de calendario, no la posición real del Sol. El nombre
solo admite letras A–Z tras normalización y la fecha acepta futuros. No hay base
ampliable, historial/exportaciones ni modo reproducible. No son pruebas de
predicción ni de causalidad astral.

Conservado conceptualmente: Enter, reducción digital, Unicode y secrets.
Reemplazados: listas, muestreo, agotamiento automático, astronomía aproximada,
interfaz/configuración y registro. La nueva implementación es independiente.

## TempleOS: qué muestra el código

Fuente primaria consultada:
https://templeos.info/Wb/Adam/God/HolySpirit.HC.HTML

GodInit carga un vocabulario y separa palabras; GodBits consume una cola de bits
y solicita temporización de interacción cuando faltan. GodWord elige un índice
mediante resto de división del entero obtenido entre el tamaño del vocabulario.
Eso puede introducir sesgo si el tamaño no divide el rango del entero. Esta
versión utiliza muestreo por rechazo y aleatoriedad del sistema operativo.
No autentiqué el Reel, sus fechas ni una supuesta predicción de 2020: no se
proporcionó el vídeo original con procedencia verificable.

## Incidencias detectadas y corregidas durante el desarrollo

1. Etiquetas OMW con y sin prefijo de idioma: corregido, con prueba específica.
2. Parámetros faltantes al aplicar filtros SQL: corregido y probado.
3. Integridad fallida en una base intermedia: descartada; reconstrucción completa
   secuencial en archivo nuevo, seguida de PRAGMA integrity_check. No se determinó
   con certeza la causa de esa corrupción intermedia. La base entregada debe
   coincidir con el hash e integridad del informe final.

## Límites de aceptación

Operativo aquí: consola, corpus real, tres modos, historial opcional, exportación,
no repetición, perfil, astronomía offline tras instalación, filtros e importación.
No probado: Windows real, instalación BAT en Windows, binario EXE.
No implementado: carta natal completa, clasificación fiable de todos los topónimos
u otras entidades históricas, categorías temáticas universales, diccionario total
de la humanidad. No se atribuye calidad lexicográfica uniforme a todos los corpus.
Las pruebas de rendimiento se refieren al hardware/entorno de ejecución del
informe, no son promesas sobre cualquier equipo.
