@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Paso 1 de 3: preparar Python.
py -3 -m venv .venv
if errorlevel 1 goto error
echo Paso 2 de 3: instalar dependencias.
.venv\Scripts\python.exe -m pip install -r requirements.txt
if errorlevel 1 goto error
if exist data\lexico.sqlite goto listo
echo Paso 3 de 3: descargar y construir diccionarios. Puede tardar varios minutos.
.venv\Scripts\python.exe -X utf8 reconstruir_datos.py
if errorlevel 1 goto error
:listo
echo Instalacion completada. Abre INICIAR_WINDOWS.bat
pause
exit /b 0
:error
echo La instalacion no se completo. Conserva el mensaje de error que aparece arriba.
echo Si no se reconoce py, instala Python 3.12 con el lanzador de Python.
pause
exit /b 1
