"""Reconstruye un snapshot únicamente si las descargas conservan el hash publicado.
Necesita internet y espacio para descargas + base temporal. No ejecuta descargas.
"""
from pathlib import Path
import hashlib,json,urllib.request,tempfile,sqlite3,os
from importar import omw,kaikki
BASE=Path(__file__).resolve().parent

def main():
    (BASE/'data').mkdir(exist_ok=True)
    manifest=json.loads((BASE/'fuentes.json').read_text(encoding='utf8'));downloads={}
    for source,meta in manifest.items():
        url=meta['url'];downloads[url]=(meta.get('sha256') or meta['archive_sha256'],meta.get('license'))
    with tempfile.TemporaryDirectory(dir=BASE) as folder:
        folder=Path(folder);db=folder/'lexico.sqlite'
        for i,(url,(expected,license)) in enumerate(downloads.items()):
            path=folder/('input'+str(i)+('.zip' if url.endswith('.zip') else '.jsonl.gz'))
            print('Descargando',url,flush=True)
            with urllib.request.urlopen(url,timeout=60) as inp,path.open('wb') as out:
                h=hashlib.sha256()
                while chunk:=inp.read(1024*1024):out.write(chunk);h.update(chunk)
            if h.hexdigest()!=expected:raise ValueError('La fuente cambió: hash distinto. No se reemplaza la base existente. Importa el nuevo corpus por separado si lo deseas.')
            if path.suffix=='.zip':omw(db,path,BASE/'licencias')
            else:kaikki(db,path,url,license)
        c=sqlite3.connect(db)
        if c.execute('PRAGMA integrity_check').fetchall()!=[('ok',)]:raise ValueError('Integridad fallida')
        c.execute('VACUUM');c.close()
        os.replace(db,BASE/'data/lexico.sqlite')
    print('Base reconstruida. Ejecuta verificar.py para nuevo informe.')
if __name__=='__main__':main()
