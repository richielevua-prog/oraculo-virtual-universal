#!/usr/bin/env python3
import argparse,csv,json,sqlite3,hashlib,sys
from pathlib import Path
from datetime import datetime,timezone
from zoneinfo import ZoneInfo
from motor import connect,profile,Pool,Deterministic,canonical
BASE=Path(__file__).resolve().parent

def prompt(text,validator):
    while True:
        value=input(text).strip()
        try:return validator(value)
        except (ValueError,KeyError) as e:print('Dato no válido:',e)

def natal_time(birth,time,zone,fold):
    naive=datetime.fromisoformat(birth+'T'+time)
    z=ZoneInfo(zone);dt=naive.replace(tzinfo=z,fold=fold)
    if dt.astimezone(timezone.utc).astimezone(z).replace(tzinfo=None)!=naive:raise ValueError('Hora inexistente por cambio de horario')
    return dt.isoformat()

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--db',type=Path,default=BASE/'data/lexico.sqlite');args=parser.parse_args()
    if not args.db.is_file():raise ValueError('Falta base lingüística: '+str(args.db))
    print('ORÁCULO MATEMÁTICO UNIVERSAL\nExperimento simbólico, sin capacidad predictiva demostrada.')
    name=prompt('Nombre completo: ',lambda x:x if x else (_ for _ in ()).throw(ValueError('vacío')))
    birth=prompt('Fecha de nacimiento (AAAA-MM-DD): ',lambda x:(profile(name,x),x)[1]);p=profile(name,birth)
    time=input('Hora de nacimiento HH:MM (opcional): ').strip()
    place=input('Lugar de nacimiento (opcional; texto local, sin geocodificación): ').strip()
    astro_iso=None
    if time:
        while True:
            try:
                zone=input('Zona IANA (ejemplo America/Mexico_City): ').strip()
                fold=prompt('Si hora repetida por cambio horario: 0 primera / 1 segunda [0]: ',lambda x:int(x or '0') if (x or '0') in ('0','1') else (_ for _ in ()).throw(ValueError('0 o 1')))
                astro_iso=natal_time(birth,time,zone,fold);break
            except (ValueError,KeyError) as e:
                print(e);time=input('Corrige hora HH:MM, o Enter para omitir: ').strip()
                if not time:break
    if astro_iso is None:
        astro_iso=input('Instante astronómico ISO con offset (Enter = ahora UTC; NO natal): ').strip() or datetime.now(timezone.utc).isoformat()
        p['astronomy_context']='generation_snapshot'
    else:p['astronomy_context']='natal'
    try:
        from astronomia import calculate
        p['astronomy']=calculate(astro_iso)
    except (ImportError,ValueError,OSError) as e:
        p['astronomy']={'unavailable':str(e)};print('Astronomía no disponible:',e)
    rules_path=BASE/'reglas_simbolicas.json'
    if rules_path.is_file():p['symbolic_rules']=json.loads(rules_path.read_text(encoding='utf8'))
    print(json.dumps(p,ensure_ascii=False,indent=2));print('Lugar no afecta cálculos geocéntricos; no se calculan casas ni ascendente.')
    mode=prompt('Modo A uniforme / B personalizado / C reproducible [A]: ',lambda x:x.upper() if x.upper() in ('A','B','C') else 'A' if not x else (_ for _ in ()).throw(ValueError('A/B/C')))
    seed=input('Semilla reproducible (solo C): ') if mode=='C' else ''
    rng=Deterministic(seed);norepeat=input('Sin repetir palabras hasta agotarlas [s/N]: ').lower()=='s'
    logging=input('Guardar historial local (incluye huella y astronomía) [s/N]: ').lower()=='s'
    c=connect(args.db);langs=();poses=();kinds=();phrases=False;seen=set();last=None;seq=0
    print('Preparando selección...');pool=Pool(c)
    with args.db.open('rb') as dbfile:db_hash=hashlib.file_digest(dbfile,'sha256').hexdigest()
    session=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f');hist=None
    if logging:
        folder=BASE/'historial';folder.mkdir(exist_ok=True);hist=open(folder/(session+'.jsonl'),'a',encoding='utf8')
    # No persistent profile/name/birth. History is opt-in.
    print('PRESIONA ENTER PARA GENERAR UNA PALABRA. /ayuda muestra comandos.')
    try:
        while True:
            cmd=input('> ').strip()
            try:
                if not cmd:
                    last=pool.draw(mode,p,rng,norepeat);seq+=1
                    if norepeat:seen.add(last['word'])
                    last.update(sequence=seq,utc=datetime.now(timezone.utc).isoformat(),profile=p,no_repeat=norepeat,algorithm='omu-v1',database_sha256=db_hash,filters={'languages':langs,'primary_pos':poses,'kinds':kinds,'phrases':phrases},seed=seed if mode=='C' else None)
                    print(last['word'])
                    if hist:hist.write(canonical(last)+'\n');hist.flush()
                elif cmd=='/salir':break
                elif cmd=='/ayuda':print('/info /ultimo /perfil /idiomas /idioma spa,jpn (o todos) /categoria n,v (o todos) /tipo proper (o todos) /frases si|no /modo A|B|C /repeticion si|no /reiniciar /historial /exportar csv|json /salir')
                elif cmd=='/perfil':print(json.dumps(p,ensure_ascii=False,indent=2))
                elif cmd=='/ultimo':print(json.dumps(last,ensure_ascii=False,indent=2))
                elif cmd=='/info':print(canonical({'total_entries':c.execute('select count(*) from entries').fetchone()[0],'eligible_remaining':sum(pool.counts.values()),'groups':pool.counts,'mode':mode,'no_repeat':norepeat,'history_enabled':logging}))
                elif cmd=='/idiomas':print(c.execute('SELECT lang,count(*) FROM entries GROUP BY lang').fetchall())
                elif cmd.startswith('/modo '):
                    new=cmd.split()[1].upper()
                    if new not in ('A','B','C'):raise ValueError('A/B/C')
                    mode=new
                    if mode=='C':seed=input('Semilla: ');rng=Deterministic(seed)
                elif cmd.startswith('/repeticion '):
                    value=cmd.split()[1]
                    if value not in ('si','no'):raise ValueError('si/no')
                    norepeat=value=='no';seen.clear();pool=Pool(c,langs,poses,kinds,phrases)
                    print('Nuevo ciclo de selección.')
                elif cmd.startswith(('/idioma ','/categoria ','/tipo ','/frases ')) or cmd=='/reiniciar':
                    if cmd=='/reiniciar':seen.clear();rng=Deterministic(seed)
                    else:
                        key,value=cmd.split(maxsplit=1);vals=() if value=='todos' else tuple(value.split(','))
                        if key=='/idioma':langs=vals
                        elif key=='/categoria':poses=vals
                        elif key=='/tipo':kinds=vals
                        else:
                            if value not in ('si','no'):raise ValueError('si/no')
                            phrases=value=='si'
                    pool=Pool(c,langs,poses,kinds,phrases,seen if norepeat else ())
                    print('Elegibles:',sum(pool.counts.values()))
                elif cmd=='/historial' or cmd.startswith('/exportar '):
                    if not hist:print('Historial desactivado en esta sesión.');continue
                    hist.flush();path=Path(hist.name)
                    if cmd=='/historial':
                        from collections import deque
                        with path.open(encoding='utf8') as recent:print(''.join(deque(recent,maxlen=20)))
                    else:
                        fmt=cmd.split()[1]
                        if fmt not in ('json','csv'):raise ValueError('csv/json')
                        out=path.with_suffix('.'+fmt)
                        with path.open(encoding='utf8') as inp,out.open('w',encoding='utf-8-sig' if fmt=='csv' else 'utf8',newline='') as f:
                            if fmt=='json':
                                f.write('[');sep=''
                                for line in inp:f.write(sep+line.strip());sep=',\n'
                                f.write(']')
                            else:
                                fields=['sequence','utc','word','lang','pos','mode','probability_numerator','probability_denominator','sources','profile'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
                                for line in inp:
                                    r=json.loads(line);row={k:canonical(r[k]) if isinstance(r[k],(dict,list)) else r[k] for k in fields}
                                    for k,v in row.items():
                                        if isinstance(v,str) and v.startswith(('=','+','-','@','\t','\r')):row[k]="'"+v
                                    w.writerow(row)
                        print(out)
                else:print('Comando desconocido. /ayuda')
            except (ValueError,LookupError,sqlite3.Error) as e:print('No se generó palabra:',e)
    finally:
        if hist:hist.close()
        c.close()
if __name__=='__main__':
    try:main()
    except (KeyboardInterrupt,EOFError):print('\nFin.')
    except Exception as e:print('Error:',e);sys.exit(1)
