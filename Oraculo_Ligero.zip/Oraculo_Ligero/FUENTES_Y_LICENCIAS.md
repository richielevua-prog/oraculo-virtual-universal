# Procedencia y derechos

Consulta: 15–16 de octubre de 2026. Los hashes exactos de los archivos importados
y las cabeceras de cada corpus figuran en `fuentes.json`. La cobertura efectiva
figura en `informe_verificacion.json`. No confundir el número de sentidos de una
web con el número de palabras únicas importadas.

## Open Multilingual Wordnet 1.4

Fuente oficial del proyecto: https://omwn.org/omw1.html
Repositorio: https://github.com/omwn/omw-data
Distribución importada: https://raw.githubusercontent.com/nltk/nltk_data/gh-pages/packages/corpora/omw-1.4.zip

Snapshot 1.4 distribuido por NLTK, no afirmamos que sea la versión más reciente.
Se importan únicamente líneas `lemma` o `idioma:lemma`, no definiciones/ejemplos.
Cada WordNet tiene autores/licencia propios. Se incluyen sin modificar los
archivos LICENSE, README y citation.bib presentes en la distribución bajo
`licencias/`. Mantén esos avisos al redistribuir la base.

Las licencias declaradas incluyen CC BY 3.0, CC BY-SA 3.0/4.0, WordNet,
MIT, Apache 2.0, ODC-BY 1.0 y CeCILL-C; algunas cabeceras son abreviadas y el texto
LICENSE correspondiente prevalece. No se relicencia toda la base como MIT.
La integración elimina duplicados NFC por grafía/idioma, retiene procedencia y
elige POS principal determinista. Esa transformación es obra de este proyecto.

Referencia académica: Francis Bond y Kyonghee Paik (2012), A survey of wordnets
and their licenses; Francis Bond y Ryan Foster (2013), Linking and extending an
open multilingual wordnet.

## Wiktionary / Kaikki / Wiktextract

Documentación y descargas: https://kaikki.org/dictionary/rawdata.html
Política de derechos: https://kaikki.org/dictionary/
Licencia Wiktionary: https://en.wiktionary.org/wiki/Wiktionary:Copyrights
Licencia CC BY-SA 4.0: https://creativecommons.org/licenses/by-sa/4.0/
Texto jurídico: https://creativecommons.org/licenses/by-sa/4.0/legalcode.txt

Datos importados:
- https://kaikki.org/dictionary/downloads/es/es-extract.jsonl.gz (98,4 MB anunciados)
- https://kaikki.org/dictionary/downloads/simple/simple-extract.jsonl.gz (4,5 MB anunciados)

Autores: colaboradores de Wikcionario/Wiktionary; extracción de Tatu Ylonen y
colaboradores de Wiktextract. Los datos Kaikki se ofrecen bajo licencias de
Wiktionary, CC BY-SA y GFDL; aquí se utiliza la vía CC BY-SA 4.0. El material
adaptado de estas fuentes sigue CC BY-SA 4.0. Mantén atribución, enlace de
licencia y este aviso de modificaciones. No hay aval de Wikimedia o Kaikki.

Modificaciones: selección de encabezados `word`, normalización Unicode NFC,
unificación de códigos ISO cuando existe equivalencia, deduplicación de sentidos,
conservación de categoría principal y marca de nombre propio cuando está disponible.
No se distribuyen definiciones completas. Los originales tienen más metadatos.

Para consultar autores e historial de una palabra: abre
`https://es.wiktionary.org/wiki/` + título codificado para fuentes `es`, o
`https://simple.wiktionary.org/wiki/` + título para `simple`; usa «Ver historial».
La columna `provenance.source` y `fuentes.json` distinguen ambas ediciones.

Referencia: Tatu Ylonen (2022), Wiktextract: Wiktionary as Machine-Readable
Structured Data, LREC, pp. 1317–1325. https://aclanthology.org/2022.lrec-1.140/

Se investigaron también los conjuntos de latín y griego antiguo de la edición
inglesa: las páginas anuncian 1,1 GB y 385,2 MB de JSONL postprocesado, marcado
como obsoleto. No se incluyen esos conjuntos completos; los vocablos históricos
incluidos proceden de la edición española descargada. El importador permite
incorporar archivos adicionales, con licencia comprobada, sin cambiar el motor.
No se han descargado todos los dumps de todas las lenguas.

## Astronomía y software

Skyfield: https://rhodesmill.org/skyfield/ (MIT).
Posiciones: https://rhodesmill.org/skyfield/positions.html
Efemérides: https://rhodesmill.org/skyfield/planets.html
Fases: https://rhodesmill.org/skyfield/almanac.html
Datos empaquetados: https://pypi.org/project/skyfield-data/
DE421: datos de efemérides del Jet Propulsion Laboratory, NASA.

Las dependencias se instalan desde PyPI con sus avisos originales; no se
redistribuyen sus binarios en este ZIP. Los detalles de versiones están en
requirements.txt; el entorno exacto utilizado para pruebas en entorno_pruebas.txt.
