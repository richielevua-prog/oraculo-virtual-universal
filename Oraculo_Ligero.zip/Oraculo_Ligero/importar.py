"""Importadores streaming; no ejecuta código del corpus."""
import argparse,gzip,json,zipfile,hashlib
import pycountry
from pathlib import Path
from motor import connect,add,canonical

def file_hash(path):
    with open(path,'rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def omw(db,archive,licenses):
    c=connect(db);z=zipfile.ZipFile(archive);root=Path(licenses);root.mkdir(exist_ok=True,parents=True)
    for item in z.namelist():
        p=Path(item)
        if not item.endswith('/') and not item.endswith('.tab'):
            dest=root.joinpath(*p.parts[1:])
            if not dest.resolve().is_relative_to(root.resolve()):raise ValueError('Ruta ZIP insegura')
            dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(item))
        if not item.endswith('.tab'):continue
        source=item; f=z.open(item);header=f.readline().decode('utf8').strip()
        c.execute('INSERT OR REPLACE INTO sources VALUES(?,?)',(source,canonical({'header':header,'archive_sha256':file_hash(archive),'url':'https://raw.githubusercontent.com/nltk/nltk_data/gh-pages/packages/corpora/omw-1.4.zip'})))
        for raw in f:
            parts=raw.decode('utf8').rstrip('\r\n').split('\t')
            if len(parts)!=3 or not (parts[1].endswith(':lemma') or parts[1]=='lemma'):continue
            lang=parts[1].split(':')[0] if ':' in parts[1] else header.split('\t')[1];pos=parts[0].rsplit('-',1)[-1];pos={'s':'a'}.get(pos,pos)
            add(c,parts[2],lang,pos,source,parts[0])
        f.close();c.commit();print(source,flush=True)
    z.close();c.close()

def kaikki(db,path,url,license):
    c=connect(db);sha=file_hash(path);source='kaikki:'+sha
    c.execute('INSERT OR REPLACE INTO sources VALUES(?,?)',(source,canonical({'url':url,'license':license,'sha256':sha})))
    opener=gzip.open if str(path).endswith('.gz') else open
    with opener(path,'rt',encoding='utf8') as f:
        for i,line in enumerate(f):
            o=json.loads(line);word=o.get('word');lang=o.get('lang_code');pos=o.get('pos','unknown')
            if not word or not lang:continue
            resolved=pycountry.languages.get(alpha_2=lang) if len(lang)==2 else None
            lang=resolved.alpha_3 if resolved else lang
            pos={'noun':'n','verb':'v','adj':'a','adv':'r'}.get(pos,pos)
            add(c,word,lang,pos,source,o.get('pos','unknown'),'proper' if pos=='name' else 'unknown')
            if i%10000==0:c.commit()
    c.commit();c.close()
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('format',choices=['omw','kaikki']);p.add_argument('file');p.add_argument('--db',default='data/lexico.sqlite');p.add_argument('--url');p.add_argument('--license');a=p.parse_args()
    if a.format=='omw':omw(a.db,a.file,'licencias')
    elif not a.url or not a.license:p.error('Kaikki requiere --url y --license verificadas')
    else:kaikki(a.db,a.file,a.url,a.license)
